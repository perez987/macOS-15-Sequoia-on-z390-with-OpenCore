## EFI with OpenCore 1.0.2

### config-14-imac-amd.plist

- SMBIOS `iMac19,1`
- IMPORTANT: fill in your own SMBIOS data
- iGPU _headless mode_ and AMD as main card
- iGPU Enabled in BIOS
- `unfairgva=6` in dGPU properties to get some kind of DRM

### config-14-macpro.plist

- SMBIOS `MacPro7,1`
- IMPORTANT: fill in your own SMBIOS data
- iGPU disabled in BIOS

### config-extra

- `config-fenvi.plist`: if you have a Fenvi combo card or any of the Broadcom wifi chipsets that have lost support in Sonoma and are included in the OCLP root patch
- `config-amfipass.plist`: to have the Fenvi card with AMFIpass.kext instead of `amfi=0x80` in boot args
- `config-ax210.plist`: if you have an Intel supported combo card (only wifi) (you can use AirportItlwm.kext on Ventura and Sonoma but on Sequoia itlwm.kext is mandatory)
- `config-ax210-bt.plist`: if you have an Intel supported combo card (wifi + Bluetooth) (you can use AirportItlwm.kext on Ventura and Sonoma but on Sequoia itlwm.kext is mandatory).

### Notes

1. Rename the selected config to `config.plist`.
  
2. Required kexts are not included because of the size of the ZIP file (only USBToolBox.kext  and UTBMap.kext are included).

3.  Fenvi and Broadcom Wi-Fi cards
    
    - [AMFIPass.kext 1.4.1](https://github.com/dortania/OpenCore-Legacy-Patcher/tree/main/payloads/Kexts/Acidanthera).
    - [IO80211FamilyLegacy.kext 1.0.0 and IOSkywalkFamily.kext 1.1.0](https://github.com/dortania/OpenCore-Legacy-Patcher/tree/main/payloads/Kexts/Wifi).
 
4. Intel supported combo cards - [OpenIntelWireless](https://github.com/OpenIntelWireless).
    
    - AirportItlwm.kext (only Ventura and Sonoma) / itlwm.kext (Ventura v2.2.0, Sonoma and Sequoia v2.3.0).
    - IntelBluetoothFirmware.kext / IntelBTPatcher.kext.
    - BlueToolFixup.kext: [BrcmPatchRAM](https://github.com/acidanthera/BrcmPatchRAM) by Acidanthera.

5. [Wi-Fi 6 Intel AX210 on macOS Sonoma](https://github.com/perez987/Intel-AX210-wifi6-on-macOS-Sonoma).
  
6. [Get back Fenvi T919 and other Broadcom Wi-Fi on macOS 14 Sonoma thanks to OLCP](https://github.com/perez987/Broadcom-wifi-back-on-macOS-Sonoma-by-OCLP).
  
7. List of kexts not included in the ZIP file (get the required on your own):  

	- AMFIPass.kext  
	- AirportItlwm.kext  
	- AppleALC.kext  
	- BlueToolFixup.kext  
	- CPUFriend.kext 
	- CPUFriendDataProvider.kext
	- IO80211FamilyLegacy.kext  
	- IOSkywalkFamily.kext  
	- IntelBTPatcher.kext
	- IntelBluetoothFirmware.kext  
	- IntelMausi.kext  
	- Lilu.kext  
	- NVMeFix.kext  
	- RestrictEvents.kext  
	- SMCProcessor.kext  
	- SMCSuperIO.kext  
	- VirtualSMC.kext  
	- WhateverGreen.kext  
	- itlwm.kext. 

8. Don't forget any other kext that you are using now.
